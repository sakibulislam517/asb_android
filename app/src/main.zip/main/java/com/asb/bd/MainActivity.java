package com.asb.bd;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    // if your website starts with www, exclude it
    private static final String myWebSite = "https://asb.com.bd/";
    private WebView mMainWebview;
    WebView webView, new_webview;
    ProgressDialog progressDialog;

    String print_status = "";

    // for handling file upload, set a static value, any number you like
    // this value will be used by WebChromeClient during file upload
    private static final int file_chooser_activity_code = 1;
    private static ValueCallback<Uri[]> mUploadMessageArr;
    private Button saveBtn;
    private EditText shortName;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (readFile().isEmpty()) {
            load_setup();
        } else {
            load_web(readFile(), "");
        }

    }

    private void load_setup() {
        setContentView(R.layout.setup);
        //file creation
        saveBtn = findViewById(R.id.saveBtn);
        shortName = findViewById(R.id.soft_name);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soft_name = shortName.getText().toString();
                writeToFile(soft_name);
            }
        });
    }

    Button printBtn;
    @SuppressLint("JavascriptInterface")
    private void load_web(String shortName, String type) {
        setContentView(R.layout.activity_main);
        mMainWebview = new WebView(MainActivity.this);
        // initialize the progressDialog
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        // get the web-view from the layout
        webView = findViewById(R.id.webView);

        printBtn = findViewById(R.id.printBtn);
        printBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createWebPrintJob(webView);
            }
        });

        // for handling Android Device [Back] key press
        webView.canGoBackOrForward(99);

        // handling web page browsing mechanism
        webView.setWebViewClient(new myWebViewClient());

        // handling file upload mechanism
        webView.setWebChromeClient(new myWebChromeClient());

        // some other settings
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setUserAgentString(new WebView(this).getSettings().getUserAgentString());

        // set the download listener
        webView.setDownloadListener(downloadListener);


        // load the website
        String load_web_url = myWebSite + shortName + "?from_where=app";
        if (type.contains("url")) {
            load_web_url = shortName;
        }
        webView.loadUrl(load_web_url);
        webView.addJavascriptInterface(new MainActivity.WebViewJavaScriptInterface(this), "app");


    }

    public class WebViewJavaScriptInterface {

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {

        }

        /**
         * method defined by developer, which will be called by web page , from web developer
         * this you can call when want to take a print, either on click of a button or directly
         * Convert HTML data, to be printed,  in form of a string and pass to this method.
         *
         * @param data
         */
        @JavascriptInterface
        public void print(final String data, String type) {
            Toast.makeText(getApplicationContext(), type, Toast.LENGTH_LONG).show();
            if (type.contains("show_btn")) {
                printBtn.setVisibility(View.VISIBLE);
            }else if (type.contains("hide_btn")) {
                printBtn.setVisibility(View.INVISIBLE);
            }else{
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        doWebViewPrint(data, type);
                    }
                });
            }

        }
    }

    private void doWebViewPrint(String ss, String type) {

        webView.setWebViewClient(new WebViewClient() {

            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
//                if (type.contains("print")) {
//                    createWebPrintJob(view);
//                }
                super.onPageFinished(view, url);
            }
        });
        if (type.contains("url")) {
            load_web(ss, "url");
            print_status = "no";
        } else {
            load_web(ss, "url");
            print_status = "yes";
            // Generate an HTML document on the fly:
//            webView.loadDataWithBaseURL(null, ss, "text/html", "UTF-8", null);
        }

    }

    private void createWebPrintJob(WebView webView) {

        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter();
        String jobName = getString(R.string.app_name) + " Document";
        PrintAttributes.Builder builder = new PrintAttributes.Builder();
        PrintJob printJob = printManager.print(jobName, printAdapter, builder.build());

        if (printJob.isCancelled()) {
            Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Not Complete", Toast.LENGTH_LONG).show();
        }


    }

    private void writeToFile(String soft_name) {
//        String soft_name = shortName.getText().toString();
//        if (soft_name.isEmpty()) {
//            Toast.makeText(MainActivity.this, "Please enter your software short name", Toast.LENGTH_SHORT).show();
//            return;
//        }


        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File directory = contextWrapper.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File txtFile = new File(directory, "config.txt");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(txtFile);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            osw.write(soft_name);
            osw.flush();
            osw.close();
            fos.close();
            Toast.makeText(contextWrapper, "Successfull - " + soft_name, Toast.LENGTH_SHORT).show();
            shortName.setText("");
            if (soft_name.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                load_web(soft_name, "");
            }

        } catch (Exception e) {
            // on below line handling the exception.
            e.printStackTrace();
        }
    }

    private String readFile() {
        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File directory = contextWrapper.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
//        Log.e("TAG", "download is : " + directory.getAbsolutePath() + "" + directory);

        File txtFile = new File(directory, "config.txt");
        StringBuilder text = new StringBuilder();
        try {
            // on below line creating and initializing buffer reader.
            BufferedReader br = new BufferedReader(new FileReader(txtFile));
            // on below line creating a string variable/
            String line;
            String new_text = "";
            // on below line setting the data to text
            while ((line = br.readLine()) != null) {
//                text.append(line);
//                text.append('');
                new_text += line;
            }
//            br.close();
            // on below line handling the exception
            return new_text;
        } catch (Exception e) {
            return "";
        }
    }

    // after the file chosen handled, variables are returned back to MainActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // check if the chrome activity is a file choosing session
        if (requestCode == file_chooser_activity_code) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri[] results = null;

                // Check if response is a multiple choice selection containing the results
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    // Response is a single choice selection
                    results = new Uri[]{data.getData()};
                }

                mUploadMessageArr.onReceiveValue(results);
                mUploadMessageArr = null;
            } else {
                mUploadMessageArr.onReceiveValue(null);
                mUploadMessageArr = null;
                Toast.makeText(MainActivity.this, "Error getting file", Toast.LENGTH_LONG).show();
            }
        }
    }

    class myWebViewClient extends android.webkit.WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            //showing the progress bar once the page has started loading
            progressDialog.show();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            // hide the progress bar once the page has loaded
            progressDialog.dismiss();

            if (print_status.contains("yes")) {
                createWebPrintJob(webView);
                Toast.makeText(MainActivity.this, "show print", Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            // show the error message = no internet access
            webView.loadUrl("file:///android_asset/no_internet.html");
            // hide the progress bar on error in loading
            progressDialog.dismiss();
            Toast.makeText(getApplicationContext(), "Internet issue", Toast.LENGTH_SHORT).show();
        }
    }

    // Calling WebChromeClient to select files from the device
    public class myWebChromeClient extends WebChromeClient {
        @SuppressLint("NewApi")
        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, FileChooserParams fileChooserParams) {

            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);

            // set single file type, e.g. "image/*" for images
            intent.setType("/");

            // set multiple file types
            String[] mimeTypes = {"image/", "application/pdf", "application/excel", "application/csv", "application/"};
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);

            Intent chooserIntent = Intent.createChooser(intent, "Choose file");
            ((Activity) webView.getContext()).startActivityForResult(chooserIntent, file_chooser_activity_code);

            // Save the callback for handling the selected file
            mUploadMessageArr = valueCallback;

            return true;
        }
    }

    DownloadListener downloadListener = new DownloadListener() {
        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {

            progressDialog.dismiss();
            Intent i = new Intent(Intent.ACTION_VIEW);

            // example of URL = https://www.example.com/invoice.pdf
            i.setData(Uri.parse(url));
            startActivity(i);
        }
    };

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            finish();
        }
    }
}