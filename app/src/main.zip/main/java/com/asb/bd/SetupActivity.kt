package com.asb.bd
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class SetupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.setup)
    }

}